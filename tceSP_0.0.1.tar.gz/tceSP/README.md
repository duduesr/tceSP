
# tceSP

<!-- badges: start -->
[![CRAN status](https://www.r-pkg.org/badges/version/tceSP)](https://CRAN.R-project.org/package=tceSP)
[![Lifecycle: stable](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://lifecycle.r-lib.org/articles/stages.html#stable)
<!-- badges: end -->

The goal of tceSP is to ...

## Installation

You can install the released version of tceSP from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("tceSP")
```

## Exemplo

This is a basic example which shows you how to solve a common problem:

``` r
library(tceSP)
## basic example code
```

