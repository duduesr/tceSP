library(testthat)
library(tceSP)

test_check("tceSP")
